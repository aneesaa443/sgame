package inputs;

import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class soundhandler {
	
	public static void RunMusic(String path) {
	try {
		AudioInputStream inputStream = AudioSystem.getAudioInputStream(new File(path));
		//The AudioSystem class acts as the entry point to the sampled audiosystem resources
		// This class lets you query and access the mixers that are installed on the system.
		Clip clip = AudioSystem.getClip();
		// Clip object.
		clip.open(inputStream);
		//The returned clip is opened(AudioInputStream) method. 
		clip.loop(0);
		// This puts the sound on loop
	} catch (UnsupportedAudioFileException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	} catch (LineUnavailableException e) {
		e.printStackTrace();
	}	
	}

}
