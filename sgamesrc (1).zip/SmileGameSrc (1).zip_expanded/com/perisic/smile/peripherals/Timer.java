package com.perisic.smile.peripherals;
import java.util.Calendar;
import java.util.Date;
import java.util.TimerTask;

        //Timer = 		A facility for threads to schedule tasks 
		//				for future execution in a background thread
		
		// TimerTask = 	A task that can be scheduled for one-time or repeated execution by a timer
        //              Is a class that contains an abstract method called RUN & when timer reaches
		//		        certain point/time, it will carry out the task once or repeatedly

public class Timer {
	
	//Use of encapsulation to prevent direct access to class variables using access modifiers
	private static final int HOUR_OF_DAY = 0;

	public static void main(String[] args ) {
		
		//Creating an instance of a timer to keep track of time
		Timer timer = new Timer();
		//Timertask created
		TimerTask task = new TimerTask() {
			
			int counter = 10;
			@Override
			//Added an anonymous inner class for implementation of the time
			//Timertask is linked to timer, when time is up it will execution run function of 
			//timertask instance
			public void run() {
				if(counter>0) {
					System.out.println(counter+ "seconds");
					counter--;
				}
				else {
					System.out.println("Sorry! You are out of time :(");
					timer.cancel();
				}
			}
		
		};
		
		Calendar date = Calendar.getInstance();
		date.set(Calendar.YEAR,2022);
		date.set(Calendar.MONTH,Calendar.DECEMBER);
		date.set(Calendar.DAY_OF_MONTH,1);
		date.set(Calendar.HOUR_OF_DAY, 15);
		date.set(Calendar.MINUTE,59);
		date.set(Calendar.SECOND,0);
		date.set(Calendar.MILLISECOND,0);
		
		timer.schedule(task,3000);
		timer.schedule(task, date.getTime());
		timer.scheduleAtFixedRate(task,0,1000);
		
	}

	private void scheduleAtFixedRate(TimerTask task, int i, int j) {
		// TODO Auto-generated method stub
		
	}

	private void schedule(TimerTask task, Date time) {
		// TODO Auto-generated method stub
		
	}

	private void schedule(TimerTask task, int i) {
		// TODO Auto-generated method stub
		
	}

	protected void cancel() {
		// TODO Auto-generated method stub
		
	}

	
		

}
