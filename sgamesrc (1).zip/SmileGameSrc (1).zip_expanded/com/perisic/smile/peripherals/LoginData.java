package com.perisic.smile.peripherals;
/**
 * Basic class. To do: 
 * link against external database.
 * signup mechanism to create account. 
 * Encryption
 * Etc.
 * @author
 *
 */
public class LoginData {
	/**
	 * Returns true if password matches the username given.
	 * @param username
	 * @param passwd
	 * @return
	 */
	
	//Implementation of virtual identity
	boolean checkPassword(String username, String passwd) { 
		if( username.equals("Rashford") && passwd.equals("Messi10")) return true;
		if( username.equals("Ronaldo") && passwd.equals("Worldcup")) return true;
		if( username.equals("Neymar") && passwd.equals("abc123")) return true;
		return false; 
		
	}
}